package manualexception;

public class ManualException extends Exception{

	private static final long serialVersionUID = 1L;

	public ManualException(String message) {
		super(message);
	}
	
	public ManualException(Exception message) {
		super(message);
	}
}
