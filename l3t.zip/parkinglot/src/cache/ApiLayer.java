package cache;


import java.util.*;

import accountdeclare.Ticket;
import manualexception.ManualException;

public class ApiLayer {
	
	CacheLayer cache = new CacheLayer();
	
	public Map<Integer,Map<String,Integer>> bluePrint() throws ManualException{
		
		return cache.bluePrint();
	}
	
	public Map<Integer, Integer> searchMySpots(int floor,String vehicleName) throws ManualException {
		
		return cache.searchMySpots(floor, vehicleName);
	}
	
	public Object ticket(Ticket ticket) throws ManualException {
		
		return cache.ticket(ticket);
	}
	
	public Map<Integer, Map<String, Integer>> showAllFloor() {
		
		return cache.showAllFloor();
	}
	public Map<Integer, Integer> reduceSpot(int floor,String vehicleName) throws ManualException {
		return cache.reduceSpot(floor,vehicleName);
	}
	
	public Map<Integer, Integer> addSpot(int floor,String vehicleName) throws ManualException {
		return cache.reduceSpot(floor,vehicleName);
	}
	
	public Map<Integer, Ticket> bookedTickets() throws ManualException {
		return cache.bookedTickets();
	}
	
	public Ticket getTicketId(int ticketId) throws ManualException {
		return cache.getTicketId(ticketId);
	}
	
	public String customerReturn(int ticketId) throws ManualException {
		return cache.customerReturn(ticketId);
	}
	
	public Ticket payCustomer(int ticketId,float fee) throws ManualException {
		
		return cache.payCustomer(ticketId, fee);
	}
}
