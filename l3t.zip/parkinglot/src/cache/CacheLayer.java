package cache;

import java.util.*;
import java.text.SimpleDateFormat;

import accountdeclare.Ticket;
import manualexception.ManualException;

public class CacheLayer {

	Map<Integer, Map<String, Integer>> bluePrint = new HashMap<>();

	Map<Integer, Integer> availableSpots = new HashMap<>();

	Map<Integer, Ticket> ticketMap = new HashMap<>();

	private int ticketId = 1000;

	private int vehicle = 3333;

	private String vehicleNum = "TN 63 A " + vehicle;

	private int ticketGen() {

		return ++ticketId;
	}

	private String vehicleNum() {

		++vehicle;

		vehicleNum = "TN 63 A " + vehicle;

		return vehicleNum;
	}

	private String vehicleType(String vehicleName) throws ManualException {

		Map<String, String> vehicleModel = new HashMap<>();

		vehicleModel.put("van", "large");
		vehicleModel.put("car", "compact");
		vehicleModel.put("truck", "large");
		vehicleModel.put("motorcycle", "motorcycle");
		vehicleModel.put("electric", "electric");
		vehicleModel.put("tricycle", "handicapped");

		return vehicleModel.get(vehicleName);
	}
	private int floor = 3;
	private int count = 2;
	public Map<Integer, Map<String, Integer>> bluePrint() throws ManualException {
	

		for (int i = 0; i < floor; i++) {
			Map<String,Integer> vehicleSpot = new HashMap<>();
			vehicleSpot.put("compact", count * floor);
			vehicleSpot.put("large", count * floor);
			vehicleSpot.put("handicapped", count * floor);
			vehicleSpot.put("motorcycle", count * floor);
			vehicleSpot.put("electric", count * floor);

			bluePrint.put(i, vehicleSpot);
		}

		return bluePrint;
	}

	public Map<Integer, Map<String, Integer>> showAllFloor() {

		return bluePrint;
	}

	public Map<Integer, Integer> searchMySpots(int floor, String vehicleType) throws ManualException {

		String vehicleMod = vehicleType(vehicleType);

		for (int i = 0; i < floor; i++) {

			availableSpots.put(i, bluePrint.get(i).get(vehicleMod));
		}

		return availableSpots;

	}

	public Map<Integer, Integer> reduceSpot(int floor, String vehicleType) throws ManualException {

		String vehicleMod = vehicleType(vehicleType);

		int spots = bluePrint.get(floor).get(vehicleMod) - 1;
		
		if(spots < 0) {
			spots = 0;
			throw new ManualException("Parking Full");
		}

		availableSpots.put(floor, spots);

		bluePrint.get(floor).put(vehicleMod, spots);

		return availableSpots;
	}
	

	public Map<Integer, Integer> addSpot(int floor, String vehicleType) throws ManualException {

		String vehicleMod = vehicleType(vehicleType);

		int spots = bluePrint.get(floor).get(vehicleMod) + 1;

		availableSpots.put(floor, spots);

		bluePrint.get(floor).put(vehicleMod, spots);

		return availableSpots;
	}
	

	public long timeGenerate() {
		
		long millis = System.currentTimeMillis();
		
		return millis;
	    
	}

	public Ticket ticket(Ticket ticket) throws ManualException {

		ticket.setDollar(4);

		ticket.setVehicleNum(vehicleNum());

		ticket.setTime(timeGenerate());

		ticket.setTicketId(ticketGen());

		ticketMap.put(ticket.getTicketId(), ticket);

		return ticket;
	}

	public Map<Integer, Ticket> bookedTickets() throws ManualException {

		if (!ticketMap.isEmpty()) {
			return ticketMap;
		}
		throw new ManualException("Still no slots booked");
	}

	public Ticket getTicketId(int ticketId) throws ManualException {

		if (ticketMap.containsKey(ticketId)) {

			return ticketMap.get(ticketId);
		}
		throw new ManualException("Id not Found || entered wrong Id");
	}
	
	public String customerReturn(int ticketId) throws ManualException {
		
		Ticket ticket = ticketMap.get(ticketId);
		
		if(ticketMap.containsKey(ticketId)) {
			
		long time = (timeGenerate() - (ticketMap.get(ticketId).getTime()))/60L;
		
		
		
		float fee = 11.5f;
		
		
		if(time == 0) {
			ticket.setDollar(4);
			return "Parking Fee: "+ticket.getDollar()+"$ for less than a hour";
		}
		if(time == 1) {
			ticket.setDollar(4);
			return "Parking Fee: "+ticket.getDollar()+"$ for "+ 1 +" hour";
		}
		if(time == 2) {
			ticket.setDollar(7.5f);
			return "Parking Fee: "+ticket.getDollar()+"$ for "+ 2 +" hours";
		}
		if(time ==3) {
			ticket.setDollar(11.5f);
			return "Parking Fee: "+ticket.getDollar()+"$ for "+ 3 +" hours";
		}

		if(time >3) {
		for(int i = (int) time ; i < 3 ; i--) {
			
			fee += 2.5f;
			
		}
		ticket.setDollar(fee);
		return "Parking Fee: "+ticket.getDollar()+"$ for "+ time +" hours";
		}
		
}
		throw new ManualException("Id not Found || Wrongly Entered");
}
	
	public Ticket payCustomer(int ticketId,float fee) throws ManualException {
		
		customerReturn(ticketId);
		
		Ticket ticket = ticketMap.get(ticketId);
		
		if(fee != ticket.getDollar()) {
			throw new ManualException("Kindly Pay Proper fee");
		}
		
		ticket.setCashType("Cash");
		
		ticket.setPaidAmount(fee);
		
		ticket.setStatus(true);
		
		addSpot(ticket.getFloor(),ticket.getVehicleTYpe());
		
		return ticket;
	}
}
