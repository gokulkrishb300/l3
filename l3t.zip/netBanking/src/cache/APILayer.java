package cache;

import java.util.List;
import java.util.Map;

import accountdeclare.*;

public class APILayer {

	CacheLayer cache = new CacheLayer();

	public String register(Customer customer,Account account) throws Exception {

		return cache.register(customer,account);
	}

	
	public String loginVerification(int customerId, int password) throws Exception {

		return cache.loginVerification(customerId, password);
	}

	public boolean addAccount(Account account) throws Exception {

		return cache.addAccount(account);
	}

	public Account accountDetails(int accountId) throws Exception {

		return cache.accountDetails(accountId);
	}
	
	public String transfer(int fromAcc, int toAcc, double amount) throws Exception {
		
		return cache.transfer(fromAcc, toAcc, amount);
	}

	public String balance(int accountId) throws Exception {

		return cache.balance(accountId);
	}
	
	public String deposit(int accountId, double amount) throws Exception {
		
		return cache.deposit(accountId,amount);
	}
	
	public String withDraw(int accountId, double amount) throws Exception {
		
		return cache.withDraw(accountId, amount);
	}
	
	public String loan(Loan loan) throws Exception {
		
		return cache.loan(loan);
	}
	
	public List<Transaction> transMap(int accountId) throws Exception {
		
		return cache.transMap(accountId);
	}
	
	public Map<String, Loan> appliedLoan(int accountId) throws Exception {
		
		return cache.appliedLoan(accountId);
	}
	
	public Map<Integer, Account> entireAccountDetails(int customerID) throws Exception {
		
		return cache.entireAccountDetails(customerID);
	}
	
	public Map<Integer, Customer> allCustomer() throws Exception {
		
		return cache.customerMap;
	}
	
	public Map<Integer, Map<Integer, Account>> allAccount() throws Exception {
		
		return cache.accountMap;
	}
	
	public Map<Integer, Map<String, Loan>> allLoan() throws Exception {
		
		return cache.loanMap;
	}
	
	public Map<Integer, List<Transaction>> allTransaction() throws Exception {
		
		return cache.transMap;
	}
	
	public String sanctionLoan(int accountId,String loanName) throws Exception {
		
		return cache.sanctionLoan(accountId, loanName);
	
	}

}