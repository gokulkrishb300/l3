package cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import accountdeclare.*;

public class CacheLayer {
	private int customerId = 1000;

	private int pwd = 200;
	
	private  int accId = 2000;
	
	private int transId = 3000;

	public int customerId() {
		return ++customerId;
	}

	public int accId() {
		return ++accId;
	}
	
	public int autoPwd() {
		return ++pwd;
	}
	
	public int transId() {
		return ++transId;
	}

	List<Transaction> list = new ArrayList<>();
	
	Map<Integer, Customer> customerMap = new HashMap<>();

 Map<Integer, Map<Integer, Account>> accountMap = new HashMap<>();
 
 Map<Integer,Map<String,Loan>> loanMap = new HashMap<>();
	
	Map<Integer,Account> insideMap = new HashMap<>();

	Map<Integer, Integer> login = new HashMap<>();
	
	Map<String,Loan> loans = new HashMap<>();
	
	Map<Integer,List<Transaction>> transMap = new HashMap<>();
	

	public String register(Customer customer,Account account) throws Exception {
		
		if(customer == null) {
			
			throw new Exception("Customer Details is null");
		}
		
		if(account == null) {
			throw new Exception("Account Details is null");
		}
		
		customer.setCustId(customerId());
		
		int customerId = customer.getCustId();
		
		customerMap.put(customerId, customer);
		
		account.setCustomerId(customerId);

		account.setAccountId(accId());
		
		int accountId = account.getAccountId();
		
		login.put(accountId, autoPwd());
		
		insideMap.put(accountId, account);
		
		accountMap.put(customerId, insideMap);
		

		return "Here's your account ID =  " + '\u0022' + accountId + '\u0022'
				+ " and Password = " + '\u0022' + login.get(accountId) + '\u0022';

		
		
	}



	public String loginVerification(int accountId, int password) throws Exception {
		
//		if(accountId == 100 && password == 123) {
//			return "admin logged in successfully";
//		}

		if (login.containsKey(accountId)) {

			if (login.get(accountId) == password) {

				return "Logged in successfully" ;
			} else {
				throw new Exception("Enter correct password");
			}
		} else {
			throw new Exception("AccountId not exist");
		}
		
	}
	  
	
		public boolean addAccount(Account account) throws Exception {

			if (account == null) {
				throw new Exception("Account Details is null");
			}

			int customerId = account.getCustomerId();

			Map<Integer, Account> mapObj = accountMap.get(customerId);
			
			if (mapObj == null) {
				
				mapObj = new HashMap<>();
				
				accountMap.put(customerId, mapObj);

			}
			account.setAccountId(accId());
			
			mapObj.put(account.getAccountId(), account);
			
			insideMap.put(account.getAccountId(), account);
			
			return true;
		}
		
		public Account accountDetails(int accId) throws Exception{
			
			if(accId <= 2000) {
				throw new Exception("invalid account ID");
			}
			
			if(insideMap.containsKey(accId)) {
				return insideMap.get(accId);
			}
			throw new Exception("Unavailable Account-ID");
		}
	  
		public String balance(int accId) throws Exception {

	
			if(insideMap.containsKey(accId)) {
				
				return "Balance : " +insideMap.get(accId).getBalance() ;
				
			
			} 
			
			throw new Exception("Invalid account-ID");
		}
		

		public String transfer(int fromAcc, int toAcc, double amount)
				throws Exception {
			
			double from = insideMap.get(fromAcc).getBalance();
			
			
			
			if(!insideMap.containsKey(toAcc)) {
				
				Transaction transaction = new Transaction();
				
				transaction.setTransId(transId());
			
				transaction.setAccId(fromAcc);
				
				transaction.setToAcc(toAcc);
				
				transaction.setTransferredAmount(amount);
				
				transaction.setTimeAndDate(dateAndTime());

				transaction.setBalance(from);
				
				transaction.setType("Debit");
				
				transaction.setStatus(false);
				
				transaction.setResult("Invalid To Account");
				
				List<Transaction> mapObj = transMap.get(fromAcc);
				
				if(mapObj == null) {
					
					mapObj = new ArrayList<>();
					
					transMap.put(fromAcc, mapObj);
				}
				
				mapObj.add(transaction);
				
			throw new Exception("Invalid To Account");	
			}
			
             if(from-amount < 0.0) {
				
                Transaction transaction = new Transaction();
				
				transaction.setTransId(transId());
				
				transaction.setAccId(fromAcc);
				
				transaction.setToAcc(toAcc);
				
				transaction.setTransferredAmount(amount);
				
				transaction.setTimeAndDate(dateAndTime());

				transaction.setBalance(from);
				
				transaction.setType("Debit");
				
				transaction.setStatus(false);
				
				transaction.setResult("Insufficient Balance");
				
				List<Transaction> mapObj = transMap.get(fromAcc);
				
				if(mapObj == null) {
					
					mapObj = new ArrayList<>();
					
					transMap.put(fromAcc, mapObj);
				}
				
				mapObj.add(transaction);
				
				
				
				throw new Exception("Insufficient Balance to Transfer");
				
			}
			
			if (amount <= 0) {
				
				Transaction transaction = new Transaction();
				
				transaction.setTransId(transId());
				
				transaction.setAccId(fromAcc);
				
				transaction.setToAcc(toAcc);
				
				transaction.setTransferredAmount(amount);
				
				transaction.setTimeAndDate(dateAndTime());

				transaction.setBalance(from);
				
				transaction.setType("Debit");
				
				transaction.setStatus(false);
				
				transaction.setResult("Negative amount");
				
				List<Transaction> mapObj = transMap.get(fromAcc);
				
				if(mapObj == null) {
					
					mapObj = new ArrayList<>();
					
					transMap.put(fromAcc, mapObj);
				}
				
				mapObj.add(transaction);
				
				throw new Exception("Transaction canceled for negative amount");
			}
			
			double to = insideMap.get(toAcc).getBalance();

			if(fromAcc == toAcc) {
				
				Transaction transaction = new Transaction();
				
				transaction.setTransId(transId());
				
				transaction.setAccId(fromAcc);
				
				transaction.setToAcc(toAcc);
				
				transaction.setTransferredAmount(amount);
				
				transaction.setTimeAndDate(dateAndTime());

				transaction.setBalance(from);
				
				transaction.setType("Debit");
				
				transaction.setStatus(false);
				
				transaction.setResult("Same Account Transfer");
				
				List<Transaction> mapObj = transMap.get(fromAcc);
				
				if(mapObj == null) {
					
					mapObj = new ArrayList<>();
					
					transMap.put(fromAcc, mapObj);
				}
				
				mapObj.add(transaction);
				
				throw new Exception("Same Account Transfer Failed");
			}
			
						Transaction transaction = new Transaction();
						
						transaction.setTransId(transId());
						
						transaction.setAccId(fromAcc);
						
						transaction.setToAcc(toAcc);
						
						transaction.setType("Debit");
						
						transaction.setTransferredAmount(amount);
						
						transaction.setTimeAndDate(dateAndTime());
						
						insideMap.get(fromAcc).setBalance(from - amount);
						
						insideMap.get(toAcc).setBalance(to + amount);
						
						from = insideMap.get(fromAcc).getBalance();
						
						transaction.setBalance(from);
						
						transaction.setResult("Success");
					
						transaction.setStatus(true);
						
						List<Transaction> mapObj = transMap.get(fromAcc);
						
						if(mapObj == null) {
							
							mapObj = new ArrayList<>();
							
							transMap.put(fromAcc, mapObj);
						}
						
						mapObj.add(transaction);
						
						return "Current Balance: " + from;
					
				} 
			
	

		
		public String deposit(int accountId , double amount) throws Exception {
			
			 double balance = insideMap.get(accountId).getBalance();
			
			if(amount <= 0) {
                
				Transaction transaction = new Transaction();
				
				transaction.setTransId(transId());
				
				transaction.setAccId(accountId);
				
				transaction.setToAcc(accountId);
				
				transaction.setTransferredAmount(amount);
				
				transaction.setTimeAndDate(dateAndTime());

				transaction.setBalance(balance);
				
				transaction.setType("Credit");
				
				transaction.setStatus(false);
				
				transaction.setResult("negative balance");
				
				List<Transaction> mapObj = transMap.get(accountId);
				
				if(mapObj == null) {
					
					mapObj = new ArrayList<>();
					
					transMap.put(accountId, mapObj);
				}
				
				mapObj.add(transaction);

				throw new Exception("Invalid Amount || Transaction Failed");
			}
			
			if(insideMap.containsKey(accountId)) {
				
				double sum = amount + balance;
				
		        insideMap.get(accountId).setBalance(sum);
		        
		    	balance = insideMap.get(accountId).getBalance();
		    	
                Transaction transaction = new Transaction();
				
				transaction.setTransId(transId());
				
				transaction.setAccId(accountId);
				
				transaction.setToAcc(accountId);
				
				transaction.setTransferredAmount(amount);
				
				transaction.setTimeAndDate(dateAndTime());

				transaction.setBalance(balance);
				
				transaction.setType("Credit");
				
				transaction.setStatus(true);
				
				transaction.setResult("Credit Success");
				
				List<Transaction> mapObj = transMap.get(accountId);
				
				if(mapObj == null) {
					
					mapObj = new ArrayList<>();
					
					transMap.put(accountId, mapObj);
				}
				
				mapObj.add(transaction);
		    	
				return "Current Balance: "+ balance;
				
			
			}
	
			throw new Exception("Invalid Acount ID || Transaction Failed");
		}
		
		public String withDraw(int accountId, double amount) throws Exception{
			
			double balance = insideMap.get(accountId).getBalance();
			
			
			if(amount<=0) {
				
				 Transaction transaction = new Transaction();
					
					transaction.setTransId(transId());
					
					transaction.setAccId(accountId);
					
					transaction.setToAcc(accountId);
					
					transaction.setTransferredAmount(amount);
					
					transaction.setTimeAndDate(dateAndTime());

					transaction.setBalance(balance);
					
					transaction.setType("Credit");
					
					transaction.setStatus(false);
					
					transaction.setResult("Negative amount");
					
					List<Transaction> mapObj = transMap.get(accountId);
					
					if(mapObj == null) {
						
						mapObj = new ArrayList<>();
						
						transMap.put(accountId, mapObj);
					}
					
					mapObj.add(transaction);
					
				throw new Exception("Invalid amount || Transaction Failed");
			}
			
			if(insideMap.containsKey(accountId)) {
					
				double diff = balance - amount;
				
				if(diff < 0.0) {
					
					balance = insideMap.get(accountId).getBalance();
					
					 Transaction transaction = new Transaction();
						
						transaction.setTransId(transId());
						
						transaction.setAccId(accountId);
						
						transaction.setToAcc(accountId);
						
						transaction.setTransferredAmount(amount);
						
						transaction.setTimeAndDate(dateAndTime());

						transaction.setBalance(balance);
						
						transaction.setType("Credit");
						
						transaction.setStatus(false);
						
						transaction.setResult("Insufficient Balance");
						
						List<Transaction> mapObj = transMap.get(accountId);
						
						if(mapObj == null) {
							
							mapObj = new ArrayList<>();
							
							transMap.put(accountId, mapObj);
						}
						
						mapObj.add(transaction);;
						
					
					throw new Exception("Insufficient balance || Transaction Failed");
				}
				
				System.out.println("Previous Balance : "+ balance);
				
				insideMap.get(accountId).setBalance(diff);
				
				balance = insideMap.get(accountId).getBalance();
				
				 Transaction transaction = new Transaction();
					
					transaction.setTransId(transId());
					
					transaction.setAccId(accountId);
					
					transaction.setToAcc(accountId);
					
					transaction.setTransferredAmount(amount);
					
					transaction.setTimeAndDate(dateAndTime());

					transaction.setBalance(balance);
					
					transaction.setType("Debit");
					
					transaction.setStatus(true);
					
					transaction.setResult("Success");
					
					List<Transaction> mapObj = transMap.get(accountId);
					
					if(mapObj == null) {
						
						mapObj = new ArrayList<>();
						
						transMap.put(accountId, mapObj);
					}
					
					mapObj.add(transaction);
					

				return "Current Balance : "+balance;
				
			
			}
			
			throw new Exception("Invalid Account Id || Transaction Failed");
		}
		
		public List<Transaction> transMap(int accountId) throws Exception {
			
			if(transMap.containsKey(accountId)) {
				
				if(transMap.get(accountId) == null) {
					
					throw new Exception("No Transaction done");
					
			
				} else {
					
				 return transMap.get(accountId);
				
				}
			}
			
			throw new Exception("No Transaction done");
			
		}
		
		private Object dateAndTime() {
			
			long millis   = System.currentTimeMillis();
			
		    java.util.Date date = new java.util.Date(millis); 
		    
		     return date;
		}
		
		public String loan(Loan loan) throws Exception {
			
			if(loan == null) {
				
				throw new Exception("Loan details is null");
			}
			
			int accountId = loan.getAccountId();
			
			Map<String,Loan> mapObj  = loanMap.get(accountId);
			
			if(mapObj == null) {
				
				mapObj = new HashMap<>();
				
				loanMap.put(accountId, mapObj);
			}
			
			mapObj.put(loan.getLoanType(),loan);
			
			loans.put(loan.getLoanType(), loan);
			
			return "--- Application Processing || Wait for Approval---" ;
			
		}
		
		public Map<String, Loan> appliedLoan(int accountId) throws Exception {
			
			if(loans == null || loans.isEmpty()) {
				return loanMap.get(accountId);
			} 
			
			return loans;
			
	
		}
		
		public Map<Integer, Account> entireAccountDetails(int customerId) throws Exception{
			
			if(accountMap.containsKey(customerId)) {
				
				return accountMap.get(customerId);
				
	
			}
			throw new Exception("Invalid CustomerID");
		}
		
		public Map<Integer, Customer> allCustomer() throws Exception {
			
			return customerMap;
		}
		
		public Map<Integer, Map<Integer, Account>> allAccount() throws Exception {
			return accountMap;
		}
		
		public Map<Integer, Map<String, Loan>> allLoan() throws Exception {
			
			return loanMap;
		}
		
		public Map<Integer, List<Transaction>> allTransaction() throws Exception {
			
			return transMap;
		}
	
		public String sanctionLoan(int accountId,String name) throws Exception {
			
			if(accountId == loans.get(name).getAccountId())
		   
				loans.get(name).setStatus(true);
			 
			double amount = loans.get(name).getAmount();
			
				deposit(accountId,amount);
			
			return "Loan Approved";
		
		}
		
		

}